import { describe, expect, it } from "vitest";
import { generateTotpSecret, totpCode, verifyTotp } from "./mfa";

describe("customer TOTP primitives", () => {
  it("generates a valid authenticator secret and verifies its current code", () => {
    const secret = generateTotpSecret();
    const now = 1_800_000_000;
    const code = totpCode(secret, Math.floor(now / 30));
    expect(secret.length).toBeGreaterThanOrEqual(30);
    expect(verifyTotp(secret, code, now)).toBe(true);
  });

  it("rejects malformed and incorrect codes", () => {
    const secret = generateTotpSecret();
    expect(verifyTotp(secret, "12345", 1_800_000_000)).toBe(false);
    expect(verifyTotp(secret, "abcdef", 1_800_000_000)).toBe(false);
  });
});
