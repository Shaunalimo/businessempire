/**
 * Canonical registry of the seven business entities (operating companies)
 * under the holding structure. Reporting currency is GBP for all entities.
 *
 * Each company has its own legal/financial records, admin area and data
 * isolation boundary (company_id on every row + Postgres RLS).
 */
export type Currency = "GBP";

export interface BusinessEntity {
  /** Stable identifier used as company_id / subdomain */
  id: string;
  name: string;
  slug: string;
  /** Human-readable description shown on public site */
  tagline: string;
  currency: Currency;
  /** Hosting subdomain, e.g. growthboost.example.com */
  domain: string;
  /** Status of regulated/sensitive capabilities */
  regulated: {
    /** Requires an authorised payment provider before money moves */
    payments: "pending-provider" | "connected";
    /** Requires FCA authorisation or an authorised partner */
    financialServices?: "pending-authorised-partner" | "connected";
    trading?: "pending-authorised-partner" | "connected";
  };
}

export const HOLDING = {
  name: "Empire Holdings (UK) Ltd",
  reportingCurrency: "GBP" as Currency,
  hqApp: "https://hq.example.com",
};

export const BUSINESSES: BusinessEntity[] = [
  {
    id: "growthboost",
    name: "GrowthBoost AI",
    slug: "growthboost",
    tagline: "AI business growth, marketing, websites, marketplace, bookings and automation.",
    currency: "GBP",
    domain: "growthboost.example.com",
    regulated: { payments: "pending-provider" },
  },
  {
    id: "ai-magazine",
    name: "AI Magazine & Comic Book Studio",
    slug: "ai-magazine",
    tagline: "AI publishing: magazines, comics, creator portfolios and creator shops.",
    currency: "GBP",
    domain: "aimagazine.example.com",
    regulated: { payments: "pending-provider" },
  },
  {
    id: "trust-vault",
    name: "Trust Vault Bank",
    slug: "trust-vault",
    tagline: "Secure customer digital vault and financial services platform.",
    currency: "GBP",
    domain: "trustvault.example.com",
    regulated: {
      payments: "pending-provider",
      financialServices: "pending-authorised-partner",
    },
  },
  {
    id: "stock-express",
    name: "Stock Market Express",
    slug: "stock-express",
    tagline: "Market intelligence, research, watchlists, portfolio tracking and paper trading.",
    currency: "GBP",
    domain: "stockexpress.example.com",
    regulated: {
      payments: "pending-provider",
      trading: "pending-authorised-partner",
    },
  },
  {
    id: "real-estate",
    name: "Real Estate Master Developments",
    slug: "real-estate",
    tagline: "Property listings, development, rentals, tenant management and portfolio tools.",
    currency: "GBP",
    domain: "realestate.example.com",
    regulated: { payments: "pending-provider" },
  },
  {
    id: "supergpu",
    name: "SUPERGPU UNIVERSAL",
    slug: "supergpu",
    tagline: "GPU optimisation, diagnostics, recovery, cloud GPU workstations and rendering.",
    currency: "GBP",
    domain: "supergpu.example.com",
    regulated: { payments: "pending-provider" },
  },
  {
    id: "dailyaccess",
    name: "DailyAccess",
    slug: "dailyaccess",
    tagline: "Personalised AI briefings, topic monitoring and verified source links.",
    currency: "GBP",
    domain: "dailyaccess.example.com",
    regulated: { payments: "pending-provider" },
  },
];

export const BUSINESS_IDS: readonly string[] = BUSINESSES.map((b) => b.id);

export function getBusiness(id: string): BusinessEntity | undefined {
  return BUSINESSES.find((b) => b.id === id);
}
