import { createRemoteJWKSet, jwtVerify } from "jose";

const GOOGLE_ISSUERS = ["https://accounts.google.com", "accounts.google.com"];
const jwks = createRemoteJWKSet(new URL("https://www.googleapis.com/oauth2/v3/certs"));

export interface GoogleIdentity { sub: string; email: string; emailVerified: true; name: string | null; picture: string | null }

/** Verify Google ID tokens server-side; never trust client-decoded claims. */
export async function verifyGoogleIdToken(token: string, audience = process.env.GOOGLE_CLIENT_ID || ""): Promise<GoogleIdentity> {
  if (!audience || token.length > 16_384) throw new Error("google_sign_in_not_configured");
  const { payload } = await jwtVerify(token, jwks, { audience, issuer: GOOGLE_ISSUERS });
  if (typeof payload.sub !== "string" || typeof payload.email !== "string" || payload.email_verified !== true) throw new Error("google_identity_unverified");
  return { sub: payload.sub, email: payload.email.trim().toLowerCase(), emailVerified: true, name: typeof payload.name === "string" ? payload.name : null, picture: typeof payload.picture === "string" ? payload.picture : null };
}
