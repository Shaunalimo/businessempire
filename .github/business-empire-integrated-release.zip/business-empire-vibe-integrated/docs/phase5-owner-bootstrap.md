# Phase 5 — first CEO provisioning

The HQ owner is provisioned from a trusted, interactive terminal, not through a public HTTP signup route.

## Before running

1. Use an isolated staging database first. Back it up and restrict network access.
2. Install dependencies and generate the Prisma client (`npm install` then `npx prisma generate --schema packages/db/prisma/schema.prisma`).
3. Apply the reviewed Prisma migrations to the target database. Do not use this script as a substitute for migrations.
4. Set `DATABASE_URL` to the intended PostgreSQL database in your local `.env` file or process environment (the bootstrap loads `.env` when present).
5. Set `AUTH_MFA_ENCRYPTION_KEY` to a securely generated base64-encoded 32-byte key. For example, generate one with `openssl rand -base64 32` in a secure environment. Store it in a secrets manager; do not commit it or reuse a development key in production.
6. Run the command from a private terminal on a trusted machine. Do not run it in CI logs, a browser, a shared terminal, or a public hosted shell.

## Provision the first CEO

Run `npm run bootstrap:ceo`. The script asks for the CEO email and a hidden password (minimum 14 characters), displays a one-time TOTP setup key/URI, and requires a valid current authenticator code before writing anything. Add the secret to an authenticator app before confirming. The secret is encrypted with AES-256-GCM before storage; the password is scrypt-hashed. The script creates the HQ company only if it is missing, creates the first `ceo` membership, and records an audit event.

A PostgreSQL transaction-scoped advisory lock serializes concurrent bootstrap attempts. The script refuses to proceed if an HQ CEO already exists or the email is already registered. There is no HTTP endpoint for creating or replacing the owner. Keep the encryption key backed up securely: losing it prevents decryption of enrolled MFA secrets.

## Important limitations

- This is a first-owner bootstrap, not a complete account-recovery system. It does not generate or validate recovery codes, reset passwords, or allow owner replacement.
- It does not provide distributed login throttling, device/session management, or automatic session cleanup.
- Run it only after reviewing and applying the database schema. The script has not been run against a real database in this source-only phase.
- The TOTP implementation is compatible with common authenticator apps but should receive independent security review and staging tests before production.
- Never send the printed secret or authenticator URI to support staff or store it in tickets, logs, source control, or screenshots.


## Phase 8 database-role requirement

After forced row-level security is applied, the one-time bootstrap must use `DIRECT_URL` with a dedicated migration/bootstrap database role that has the required schema privileges and `BYPASSRLS` (or a superuser only for a controlled initial setup). The script checks this before provisioning. Never use this privileged URL in a web application, never expose it to clients, and rotate it after initial setup where practical. Normal application services must use a separate non-owner, non-superuser, non-`BYPASSRLS` runtime role.
