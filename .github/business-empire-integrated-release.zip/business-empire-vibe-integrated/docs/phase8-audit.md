# Phase 8 audit record

## Delivered source changes

- Shared transaction-scoped tenant session verifier: `packages/db/src/tenant.ts`.
- Unit tests: `packages/db/src/tenant.test.ts`.
- Shared DB package exports and app dependencies updated for all seven business workspaces.
- Fixed-tenant API guards added to all seven business apps; customer summary/export and staff/admin summary endpoints now pass through authentication, membership and role checks before returning an explicit not-implemented response.
- Phase 8 PostgreSQL migration adds membership-gated company discovery, read-only memberships, append-only audit records, user-scoped recovery codes and immutable intercompany authorisations.
- HQ CEO session resolver, login membership lookup, recovery-code consumption, and session audit writes now set transaction-local user/company context.
- One-time CEO bootstrap now requires the dedicated `DIRECT_URL` and verifies the database role can perform controlled provisioning with forced RLS enabled.
- All Next.js workspaces declare shared package transpilation.
- Opt-in PostgreSQL integration script checks company discovery, tenant-scoped reads, membership scoping and cross-tenant insert rejection.

## Checks run in this environment

- `node scripts/preflight.mjs` — PASS.
- `node scripts/check-rls.mjs` — PASS.
- `node --check` on the new PostgreSQL test script, CEO bootstrap script and all Next.js config files — PASS.
- Custom structural audit of all 21 protected routes and their shared helper imports — PASS.
- ZIP integrity check — performed after packaging.

## Checks not run

- Node dependencies are not installed in this workspace; Vitest, TypeScript type-check, Prisma validation and Next.js production builds were not run.
- No PostgreSQL server or `psql` binary is available here. The Phase 8 migration was not applied and the opt-in cross-tenant database integration test was not run.
- No browser tests, penetration test, independent security review or production deployment was performed.

## Important operational limits

- Business-app login endpoints still return 501; Phase 8 does not issue the seven business-app session cookies. Do not manually create those cookies.
- The protected business endpoints return 503 after successful authorization until their real data contracts and scoped queries are implemented. This avoids returning invented figures or implying data is live.
- The custom `app.user_id` and `app.company_id` PostgreSQL settings are trusted server-side application context. They do not defend against arbitrary SQL execution under the same database role; SQL injection prevention and database least privilege remain essential.
- Apply migrations in order using a controlled migration connection. Web applications must use a separate runtime role that is not a table owner, superuser or `BYPASSRLS`.
