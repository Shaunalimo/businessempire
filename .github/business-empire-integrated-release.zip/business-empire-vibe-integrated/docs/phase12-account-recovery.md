# Phase 12 — customer account recovery and session controls

## Added across all seven customer applications

- Password-reset request endpoint with a generic response for known and unknown email addresses.
- Reset links use cryptographically random tokens; only SHA-256 token hashes are stored.
- Reset tokens expire after 30 minutes and are consumed atomically once.
- Successful reset changes the password and revokes every existing customer session and outstanding reset token.
- Authenticated password change requires the current password and, when enrolled, a valid TOTP code. Other active sessions are revoked.
- Session listing exposes only session ID, creation/expiry timestamps and whether the session is the current device; raw session tokens are never returned.
- Customers can revoke one of their own sessions or revoke all other sessions while keeping the current device signed in.
- Requests use same-origin checks and the existing database-backed auth throttle.
- CEO Headquarters authentication remains separate.

## Endpoints

- `POST /api/auth/password-reset/request` — `{ "email": "customer@example.com" }`; generic response. Delivery uses the configured transactional email webhook.
- `POST /api/auth/password-reset/confirm` — `{ "token": "...", "password": "minimum 12 characters" }`.
- `POST /api/auth/password/change` — authenticated `{ "currentPassword": "...", "newPassword": "...", "mfaCode": "123456" }`; `mfaCode` is required when MFA is enrolled.
- `GET /api/auth/sessions` — list active session metadata for the signed-in customer.
- `DELETE /api/auth/sessions` — `{ "sessionId": "..." }` to revoke one owned session, or `{ "revokeOthers": true }` to revoke every other session.

## Migration and configuration

Apply the new Prisma migration `20261116200000_phase12_account_recovery` after reviewing the SQL. The existing `AUTH_EMAIL_WEBHOOK_URL`, `AUTH_EMAIL_WEBHOOK_SECRET`, and `PUBLIC_APP_URL` settings must point to a trusted HTTPS email adapter and canonical app URL. The adapter must avoid logging reset tokens and must prevent open-relay behaviour.

## Launch gates and limitations

- Email delivery is not live until a real transactional email adapter is configured and tested.
- Migration application, Prisma generation/validation, full TypeScript checks, automated tests, production builds, concurrency/load tests, security review and deployment have not been performed in this source package.
- The existing throttle is a baseline and needs reverse-proxy configuration and load testing.
- Password-reset pages/front-end forms are not included; these endpoints require UI integration.
- Do not enable public registration or launch account recovery until the email adapter, migration, UI, abuse monitoring and independent security review are complete.
- Reset tokens and session rows are identity-service data, not tenant-owned business records; retain least-privilege database grants and do not expose them through customer dashboards.
