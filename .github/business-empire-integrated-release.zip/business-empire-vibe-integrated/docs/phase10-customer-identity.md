# Phase 10 — Shared customer identity foundation

## Delivered in source
- Seven business applications now share the same User and Session tables and common password/session primitives.
- Each application exposes fixed-company registration, login, logout and session introspection endpoints.
- Registration assigns only the `customer` role in the current app's fixed company; clients cannot submit company IDs or roles.
- Sessions use random 256-bit opaque tokens; only SHA-256 token hashes are stored. Cookies are HttpOnly, SameSite=Strict, path-scoped and Secure in production.
- State-changing authentication endpoints enforce exact same-origin Origin/Host checks.
- Dashboard now checks its server-side session and offers sign-out rather than presenting fabricated account data.

## Critical limitations before production
- Email verification and verified-email password reset delivery are not implemented. Account recovery page explicitly says so.
- Customer MFA enrolment and verification are not implemented. Users with MFA already enabled are denied customer login rather than bypassing MFA.
- Rate limiting for customer login/registration, bot protection, breached-password checks, privacy/consent workflow, terms acceptance, account deletion/export workflow, security notifications and external identity provider integration remain outstanding.
- Public registration is disabled by default (`CUSTOMER_REGISTRATION_ENABLED=false`). Do not enable it until verified-email tokens, abuse controls, consent records and support workflows are implemented and independently tested.
- Trust Vault customer identity does not confer permission to use regulated banking/payment features. KYC/AML, FCA/PRA permissions or authorised partner arrangements and product-specific approvals remain mandatory.
- Runtime DB credentials must be least-privilege and migrations must be applied by a separate migration role. Do not run app services as table owner, superuser or BYPASSRLS.
- This source has not been deployed or connected to a production database.

## Manual setup
1. Configure DATABASE_URL and DIRECT_URL with a dedicated least-privilege runtime role.
2. Apply migrations with a separate migration credential and validate the RLS policies.
3. Install dependencies, generate Prisma Client, run typecheck/tests/build for all seven apps.
4. Add verified email delivery and one-time token storage before enabling public registration.
5. Add customer MFA, recovery, rate limiting and audit/alert workflows.
6. Complete independent security review and data-protection review before launch.
