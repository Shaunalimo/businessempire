# Build notes (changes made on top of the source archives)

Base: `business-empire-vibe-integrated-source` (nine workspaces incl. Vibe Coding Platform).
Merged in from `CEO_Business_Empire_All_7_Businesses_Source_Code`: `scripts/start-all.mjs`
(extended to nine apps) and the `dev:all` / `release:verify` npm scripts.

## Fixes
- `packages/core/src/entities.ts`: `BUSINESS_IDS` used `as const` on a `.map()` result (TS1355) -> typed `readonly string[]`.
- `packages/core/src/payments.ts`: `SimulatedProvider` methods declared no parameters, so calls in
  `payments.test.ts` failed type-checking -> methods now accept the interface parameters.
- `infra/docker-compose.yml`: previous version had invalid `args:` placement and only 2 apps; the Nov-16
  version mapped host `300X:3000` although each app listens on `300X` in-container. Now all nine apps,
  symmetric ports, shared env, `.env` passed through.
- `infra/app.Dockerfile`: installs OpenSSL (Prisma on Alpine) and runs `prisma generate` before `next build`.

## Verified here (no network, no node_modules)
- `npm run release:verify` (all static structural/RLS/identity checks) passes.
- `packages/core` type-checks cleanly (vitest stubbed), including test files.

## NOT verified (needs a machine with npm access)
`npm install`, Prisma generate/validate, Vitest, `next build` for the nine apps, Docker image builds,
migrations, RLS runtime tests, browser tests. Fixes to compose/Dockerfile are untested.
