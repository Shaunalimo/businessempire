import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const schema = fs.readFileSync(path.join(root, 'packages/db/prisma/schema.prisma'), 'utf8');
const sql = fs.readFileSync(path.join(root, 'packages/db/policies/rls.sql'), 'utf8');
const migration = fs.readFileSync(path.join(root, 'packages/db/prisma/migrations/20261116160000_phase7_rls_hardening/migration.sql'), 'utf8');
const phase8 = fs.readFileSync(path.join(root, 'packages/db/prisma/migrations/20261116170000_phase8_tenant_api_context/migration.sql'), 'utf8');
const phase14 = fs.readFileSync(path.join(root, 'packages/db/prisma/migrations/20261117170000_phase14_vibe_coding_platform/migration.sql'), 'utf8');
const errors = [];
const check = (ok, msg) => { if (!ok) errors.push(msg); };
for (const field of ['companyId','userId','fromCompanyId','toCompanyId']) {
  check(schema.includes(`${field} `), `Prisma schema missing expected field ${field}`);
}
for (const table of ['Company','Product','Customer','Subscription','Payment','Expense','LedgerAccount','JournalEntry','Integration','UserCompany','AuditLog','IntercompanyAuthorisation']) {
  check(sql.includes(`'${table}'`) || sql.includes(`"${table}"`), `RLS SQL missing table ${table}`);
  check(sql.includes(`ALTER TABLE %I FORCE ROW LEVEL SECURITY`) || sql.includes(`ALTER TABLE "${table}" FORCE ROW LEVEL SECURITY`), `RLS force policy missing for ${table}`);
}
check(sql.includes('"companyId"'), 'RLS SQL must use quoted Prisma camelCase companyId');
check(sql.includes('"userId"'), 'RLS SQL must scope memberships by userId');
check(!/^\s*SELECT\s+set_config/im.test(sql), 'Canonical policy file must not set request tenant context during migration');
check(migration === sql, 'Phase 7 migration must match canonical RLS policy file');
check(!sql.includes('company_id = current_setting'), 'Legacy snake_case policy expression remains');
check(phase8.includes('membership.\"userId\"') && phase8.includes('membership.\"companyId\"'), 'Phase 8 Company policy must resolve company only through authenticated membership');
check(phase8.includes("current_setting('app.user_id', true)"), 'Phase 8 Company policy must require authenticated user context');
check(phase8.includes('FOR SELECT') && phase8.includes('user_membership_read_self'), 'Phase 8 must make memberships read-only for runtime tenant roles');
check(phase8.includes('tenant_audit_insert') && !/CREATE POLICY\s+tenant_isolation\s+ON\s+\"AuditLog\"/i.test(phase8), 'Phase 8 must make tenant audit records append-only');
check(phase8.includes('recovery_code_user_scope') && phase8.includes('ALTER TABLE \"RecoveryCode\" FORCE ROW LEVEL SECURITY'), 'Phase 8 must force recovery codes to the authenticated user');
check(phase8.includes('intercompany_origin_insert') && phase8.includes('intercompany_participant_read'), 'Phase 8 must make intercompany authorisations immutable for runtime roles');
for (const table of ['VibeProject','VibeProjectFile','VibeProjectRun','VibePlanSubscription','VibeMarketplaceListing']) {
  check(phase14.includes(`ALTER TABLE \"${table}\" ENABLE ROW LEVEL SECURITY`) && phase14.includes(`ALTER TABLE \"${table}\" FORCE ROW LEVEL SECURITY`), `Phase 14 must enable and force RLS for ${table}`);
}
check(phase14.includes('vibe_marketplace_public_or_owner_read') && phase14.includes(`"status" = 'published'`), 'Marketplace public read must be limited to published listings');
check(phase14.includes('vibe_project_owner_insert') && phase14.includes('ownerUserId'), 'Vibe projects must be owner-attributed');
check(phase14.includes('vibe_plan_owner_scope') && phase14.includes('\"userId\" = NULLIF(current_setting(\'app.user_id\', true), \'\')'), 'Vibe plan entitlements must be scoped to the authenticated account');
check(phase14.includes('VibeProjectRun') && phase14.includes('\"inputTokens\"') && phase14.includes('\"outputTokens\"'), 'Vibe generation runs must record token usage metadata');
if (errors.length) { console.error('RLS structural check FAILED'); for (const e of errors) console.error(`- ${e}`); process.exit(1); }
console.log('RLS structural check PASSED: Prisma identifiers, tenant tables, forced RLS, migration parity and membership-gated company resolution verified.');
console.log('This is a static check only; PostgreSQL migration and cross-tenant integration tests remain required.');
