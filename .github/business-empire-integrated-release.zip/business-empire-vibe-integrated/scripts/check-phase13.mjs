import fs from 'node:fs';
import path from 'node:path';
const apps=['growthboost','ai-magazine','trust-vault','stock-express','real-estate','supergpu','dailyaccess'];
const required=['app/account-recovery/page.tsx','app/reset-password/page.tsx','app/security/page.tsx','app/dashboard/page.tsx'];
const errors=[];
for(const app of apps){for(const rel of required){const f=path.join('apps',app,rel);if(!fs.existsSync(f))errors.push(`${app}: missing ${rel}`);}
 const recovery=fs.readFileSync(path.join('apps',app,'app/account-recovery/page.tsx'),'utf8');
 const reset=fs.readFileSync(path.join('apps',app,'app/reset-password/page.tsx'),'utf8');
 const security=fs.readFileSync(path.join('apps',app,'app/security/page.tsx'),'utf8');
 if(!recovery.includes('/api/auth/password-reset/request'))errors.push(`${app}: recovery UI not wired`);
 if(!reset.includes('/api/auth/password-reset/confirm'))errors.push(`${app}: reset UI not wired`);
 if(!security.includes('/api/auth/sessions')||!security.includes('/api/auth/password/change'))errors.push(`${app}: security UI missing account controls`);
}
if(errors.length){console.error(errors.join('\n'));process.exit(1);}
console.log(`Phase 13 structural check passed: ${apps.length} account centres and recovery pages.`);
