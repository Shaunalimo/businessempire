import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const apps = ['growthboost','ai-magazine','trust-vault','stock-express','real-estate','supergpu','dailyaccess'];
const required = [
  'app/api/auth/password-reset/request/route.ts',
  'app/api/auth/password-reset/confirm/route.ts',
  'app/api/auth/password/change/route.ts',
  'app/api/auth/sessions/route.ts'
];
let errors=[];
for (const app of apps) {
  for (const rel of required) if (!fs.existsSync(path.join(root,'apps',app,rel))) errors.push(`${app}: missing ${rel}`);
  const lib=fs.readFileSync(path.join(root,'apps',app,'lib/identity.ts'),'utf8');
  for (const name of ['requestCustomerPasswordReset','confirmCustomerPasswordReset','changeCustomerPassword','listCustomerSessions','revokeCustomerSessions']) if(!lib.includes(`function ${name}`)) errors.push(`${app}: missing ${name}`);
  if (!lib.includes('tokenHash: sha256(raw)')) errors.push(`${app}: reset token is not hashed before storage`);
  if (!lib.includes('revokedAt: new Date()')) errors.push(`${app}: session revocation missing`);
}
const schema=fs.readFileSync(path.join(root,'packages/db/prisma/schema.prisma'),'utf8');
const migration=path.join(root,'packages/db/prisma/migrations/20261116200000_phase12_account_recovery/migration.sql');
if(!schema.includes('model PasswordResetToken')) errors.push('Prisma PasswordResetToken model missing');
if(!fs.existsSync(migration)) errors.push('Phase 12 migration missing');
if(errors.length){console.error(errors.join('\n'));process.exit(1);}
console.log(`Phase 12 structural check passed: ${apps.length} customer apps, ${apps.length*required.length} routes, token hashing and migration present.`);
