#!/usr/bin/env node
/** One-time, interactive first-CEO provisioning. Run only from a trusted terminal. */
import 'dotenv/config';
import { createRequire } from 'node:module';
import { createCipheriv, createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import { createInterface } from 'node:readline';

const require = createRequire(import.meta.url);
const { PrismaClient } = require('@prisma/client');
let prisma;
const issuer = 'Business Empire HQ';
const rl = createInterface({ input: process.stdin, output: process.stdout });
const ask = (q) => new Promise((resolve) => rl.question(q, resolve));

function hidden(prompt) {
  if (!process.stdin.isTTY || !process.stdout.isTTY) throw new Error('CEO bootstrap requires an interactive TTY.');
  return new Promise((resolve) => {
    process.stdout.write(prompt);
    let value = '';
    const onData = (chunk) => {
      for (const char of chunk.toString()) {
        if (char === '\u0003') { process.stdout.write('\n'); cleanup(); process.exit(130); }
        if (char === '\r' || char === '\n') { process.stdout.write('\n'); cleanup(); resolve(value); return; }
        if (char === '\u007f' || char === '\b') { value = value.slice(0, -1); continue; }
        if (char >= ' ' && char <= '~') value += char;
      }
    };
    const cleanup = () => { process.stdin.off('data', onData); if (process.stdin.isTTY) process.stdin.setRawMode(false); };
    process.stdin.setRawMode(true); process.stdin.resume(); process.stdin.on('data', onData);
  });
}

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function base32Encode(buffer) {
  let bits = 0, value = 0, out = '';
  for (const byte of buffer) { value = (value << 8) | byte; bits += 8; while (bits >= 5) { out += alphabet[(value >>> (bits - 5)) & 31]; bits -= 5; } }
  if (bits) out += alphabet[(value << (5 - bits)) & 31];
  return out;
}
function base32Decode(value) {
  let bits = 0, acc = 0; const bytes = [];
  for (const char of value) { const n = alphabet.indexOf(char); if (n < 0) throw new Error('Invalid Base32 secret'); acc = (acc << 5) | n; bits += 5; if (bits >= 8) { bytes.push((acc >>> (bits - 8)) & 255); bits -= 8; } }
  return Buffer.from(bytes);
}
function totp(secret, step) {
  const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(step));
  const digest = createHmac('sha1', base32Decode(secret)).update(counter).digest();
  const offset = digest[digest.length - 1] & 15;
  const binary = ((digest[offset] & 127) << 24) | ((digest[offset + 1] & 255) << 16) | ((digest[offset + 2] & 255) << 8) | (digest[offset + 3] & 255);
  return String(binary % 1_000_000).padStart(6, '0');
}
function verifyTotp(secret, code) {
  if (!/^\d{6}$/.test(code)) return false;
  const step = Math.floor(Date.now() / 30_000);
  return [step - 1, step, step + 1].some((s) => { const a = Buffer.from(totp(secret, s)); const b = Buffer.from(code); return timingSafeEqual(a, b); });
}
function encryptedSecret(secret, key) {
  const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()]);
  return `${iv.toString('hex')}:${cipher.getAuthTag().toString('hex')}:${encrypted.toString('hex')}`;
}
function passwordHash(password) {
  const salt = randomBytes(16); const hash = scryptSync(password, salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

async function main() {
  if (!process.stdin.isTTY || !process.stdout.isTTY) throw new Error('Run this command directly in a trusted interactive terminal.');
  if (!process.env.DIRECT_URL) throw new Error('DIRECT_URL is required for one-time CEO provisioning; do not use the normal application runtime database role.');
  prisma = new PrismaClient({ datasources: { db: { url: process.env.DIRECT_URL } } });
  const role = await prisma.$queryRaw`SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user`;
  if (!role[0] || (!role[0].rolsuper && !role[0].rolbypassrls)) throw new Error('DIRECT_URL must use a restricted migration/bootstrap role with BYPASSRLS (or a superuser) because forced RLS is active. Keep this credential private and never use it in web applications.');
  const key = Buffer.from(process.env.AUTH_MFA_ENCRYPTION_KEY || '', 'base64');
  if (key.length !== 32) throw new Error('AUTH_MFA_ENCRYPTION_KEY must be a base64-encoded 32-byte key.');

  console.log('\nFIRST CEO ACCOUNT SETUP — one-time operation');
  console.log('Use a trusted machine and a private screen. The authenticator secret is shown once.\n');
  const email = (await ask('CEO email: ')).trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.');
  const password = await hidden('New password (minimum 14 characters, hidden): ');
  const confirm = await hidden('Confirm password (hidden): ');
  if (password.length < 14 || password !== confirm) throw new Error('Passwords must match and contain at least 14 characters.');

  const secret = base32Encode(randomBytes(20));
  const uri = `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(email)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
  console.log('\nAdd this account to an authenticator app before continuing.');
  console.log(`Manual setup key: ${secret}`);
  console.log(`Authenticator URI: ${uri}\n`);
  const code = (await ask('Enter the current 6-digit authenticator code to confirm setup: ')).trim();
  if (!verifyTotp(secret, code)) throw new Error('Authenticator code did not verify. No CEO account was created.');

  const hash = passwordHash(password);
  const mfaSecretEnc = encryptedSecret(secret, key);
  const result = await prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT pg_advisory_xact_lock(781234560012345678)`;
    const hq = await tx.company.findUnique({ where: { slug: 'hq' } });
    if (hq) {
      const existingCeo = await tx.userCompany.findFirst({ where: { companyId: hq.id, role: 'ceo' } });
      if (existingCeo) throw new Error('An HQ CEO already exists. Bootstrap is permanently closed.');
    }
    if (await tx.user.findUnique({ where: { email } })) throw new Error('That email already belongs to a user.');
    const company = hq ?? await tx.company.create({ data: { slug: 'hq', name: 'Business Empire Headquarters', currency: 'GBP' } });
    const user = await tx.user.create({ data: { email, passwordHash: hash, mfaSecretEnc, mfaEnrolled: true, isActive: true } });
    await tx.userCompany.create({ data: { userId: user.id, companyId: company.id, role: 'ceo' } });
    await tx.auditLog.create({ data: { actorId: user.id, action: 'hq.owner.bootstrap', subject: user.id } });
    return { userId: user.id, companyId: company.id };
  }, { isolationLevel: 'Serializable' });

  console.log('\nCEO account created and authenticator verified. Store your password and recovery arrangements securely.');
  console.log(`User ID: ${result.userId}`);
  console.log('You can now sign in to HQ with your email, password and authenticator code.');
}

main().catch((error) => { console.error(`\nBootstrap failed: ${error.message}`); process.exitCode = 1; })
  .finally(async () => { rl.close(); if (prisma) await prisma.$disconnect(); });
