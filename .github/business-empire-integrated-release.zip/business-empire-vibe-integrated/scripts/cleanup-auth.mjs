#!/usr/bin/env node
import 'dotenv/config';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
try {
  const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const sessions = await prisma.session.deleteMany({ where: { OR: [{ expiresAt: { lt: new Date() } }, { revokedAt: { lt: cutoff } }] } });
  const throttles = await prisma.authThrottle.deleteMany({ where: { updatedAt: { lt: cutoff }, OR: [{ lockedUntil: null }, { lockedUntil: { lt: new Date() } }] } });
  console.log(`Auth cleanup complete: ${sessions.count} old sessions, ${throttles.count} old throttle records removed.`);
} finally { await prisma.$disconnect(); }
