import type { Metadata } from "next";
export const metadata: Metadata = { title: "CEO Master Dashboard", description: "Group headquarters" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en-GB"><body>{children}</body></html>);
}
