import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "trust-vault", status: "ok", ts: new Date().toISOString() });
}
