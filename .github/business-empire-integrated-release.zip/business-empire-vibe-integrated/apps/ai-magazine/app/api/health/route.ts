import { NextResponse } from "next/server";
export async function GET() {
  return NextResponse.json({ app: "ai-magazine", status: "ok", ts: new Date().toISOString() });
}
