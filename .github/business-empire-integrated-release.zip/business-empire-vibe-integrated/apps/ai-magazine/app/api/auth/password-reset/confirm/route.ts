import { confirmCustomerPasswordReset } from "../../../../../lib/identity";
export async function POST(req: Request) { return confirmCustomerPasswordReset(req); }
