import { verifyCustomerEmail } from "../../../../../../lib/identity";
export async function POST(req: Request) { return verifyCustomerEmail(req); }
