import { changeCustomerPassword } from "../../../../../lib/identity";
export async function POST(req: Request) { return changeCustomerPassword(req); }
