import { rotateCustomerRecoveryCodes } from "../../../../lib/identity";
export async function POST(req: Request) { return rotateCustomerRecoveryCodes(req); }
