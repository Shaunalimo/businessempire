import { NextResponse } from "next/server";
import { isSameOriginRequest, sha256 } from "@empire/core";
import { prisma } from "@empire/db";

export const NO_STORE = { "Cache-Control": "no-store" };

export function rejectVibeOrigin(request: Request) {
  if (!isSameOriginRequest(request.headers)) {
    return NextResponse.json({ error: "origin_check_failed" }, { status: 403, headers: NO_STORE });
  }
  return null;
}

/** Shared database throttle; only the reverse proxy's x-real-ip is trusted. */
export async function vibeRateLimited(request: Request, action: string, subject = "", includeIp = true) {
  const ip = includeIp ? (request.headers.get("x-real-ip") || "unknown") : "account";
  const key = sha256(`vibe:${action}:${ip}:${subject}`);
  const now = new Date();
  const windowMs = 15 * 60 * 1000;
  const current = await prisma.authThrottle.findUnique({
    where: { key },
    select: { windowStartedAt: true, attempts: true, lockedUntil: true },
  });
  if (current?.lockedUntil && current.lockedUntil > now) return true;
  const expired = !current || now.getTime() - current.windowStartedAt.getTime() >= windowMs;
  const attempts = expired ? 1 : (current?.attempts || 0) + 1;
  const lockedUntil = attempts >= 8 ? new Date(now.getTime() + 15 * 60 * 1000) : null;
  await prisma.authThrottle.upsert({
    where: { key },
    create: { key, windowStartedAt: now, attempts, lockedUntil },
    update: { windowStartedAt: expired ? now : current!.windowStartedAt, attempts, lockedUntil },
  });
  return Boolean(lockedUntil);
}
