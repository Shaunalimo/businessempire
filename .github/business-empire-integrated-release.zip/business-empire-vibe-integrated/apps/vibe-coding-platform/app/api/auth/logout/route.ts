import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { prisma } from "@empire/db";
import { sha256 } from "@empire/core";
import { VIBE_SESSION_COOKIE } from "../../../../lib/auth";
import { NO_STORE, rejectVibeOrigin } from "../../../../lib/security";

export async function POST(request: Request) {
  const blocked = rejectVibeOrigin(request);
  if (blocked) return blocked;
  const token = cookies().get(VIBE_SESSION_COOKIE)?.value;
  if (token) {
    try {
      await prisma.session.updateMany({ where: { tokenHash: sha256(token), revokedAt: null }, data: { revokedAt: new Date() } });
    } catch {
      return NextResponse.json({ error: "sign_out_unavailable" }, { status: 503, headers: NO_STORE });
    }
  }
  const response = NextResponse.json({ ok: true }, { headers: NO_STORE });
  response.cookies.set(VIBE_SESSION_COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 0 });
  return response;
}
