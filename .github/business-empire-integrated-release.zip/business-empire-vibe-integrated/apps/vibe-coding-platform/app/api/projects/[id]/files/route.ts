import { NextResponse } from "next/server";
import { isSafeVibeProjectPath, isVibeBusinessSlug } from "@empire/core";
import { getVibeSession, withVibeTenant } from "../../../../../lib/auth";
import { NO_STORE, rejectVibeOrigin } from "../../../../../lib/security";

export async function GET(request: Request, context: { params: { id: string } }) {
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const target = new URL(request.url).searchParams.get("business") || "growthboost";
  if (!isVibeBusinessSlug(target)) return NextResponse.json({ error: "invalid_business_target" }, { status: 400, headers: NO_STORE });
  const result = await withVibeTenant(session, target, async ({ tx, companyId, role }) => {
    const project = await tx.vibeProject.findFirst({ where: { id: context.params.id, companyId, ...(role === "customer" ? { ownerUserId: session.userId } : {}) }, select: { id: true } });
    if (!project) return null;
    return tx.vibeProjectFile.findMany({ where: { projectId: project.id }, orderBy: { path: "asc" }, select: { id: true, path: true, language: true, content: true, version: true, updatedAt: true } });
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers: NO_STORE });
  if (!result.value) return NextResponse.json({ error: "project_not_found" }, { status: 404, headers: NO_STORE });
  return NextResponse.json({ files: result.value }, { headers: NO_STORE });
}

export async function PUT(request: Request, context: { params: { id: string } }) {
  const blocked = rejectVibeOrigin(request);
  if (blocked) return blocked;
  const session = await getVibeSession();
  if (!session) return NextResponse.json({ error: "authentication_required" }, { status: 401, headers: NO_STORE });
  const body = await request.json().catch(() => null);
  const target = body?.businessSlug;
  const path = body?.path;
  const content = typeof body?.content === "string" ? body.content : null;
  const language = typeof body?.language === "string" ? body.language.slice(0, 32) : "text";
  if (!isVibeBusinessSlug(target) || !isSafeVibeProjectPath(path) || content === null || content.length > 1_000_000) {
    return NextResponse.json({ error: "invalid_file_path_or_content" }, { status: 400, headers: NO_STORE });
  }
  const result = await withVibeTenant(session, target, async ({ tx, companyId }) => {
    const project = await tx.vibeProject.findFirst({ where: { id: context.params.id, companyId, ownerUserId: session.userId }, select: { id: true } });
    if (!project) return null;
    const existing = await tx.vibeProjectFile.findUnique({ where: { projectId_path: { projectId: project.id, path } }, select: { id: true, version: true } });
    const file = existing
      ? await tx.vibeProjectFile.update({ where: { id: existing.id }, data: { content, language, version: { increment: 1 } }, select: { id: true, path: true, language: true, version: true, updatedAt: true } })
      : await tx.vibeProjectFile.create({ data: { projectId: project.id, path, language, content }, select: { id: true, path: true, language: true, version: true, updatedAt: true } });
    await tx.vibeProject.update({ where: { id: project.id }, data: { updatedAt: new Date() } });
    await tx.auditLog.create({ data: { actorId: session.userId, companyId, action: "vibe.project.file_saved", subject: `${project.id}:${path}` } });
    return file;
  });
  if (!result.ok) return NextResponse.json({ error: result.error }, { status: result.status, headers: NO_STORE });
  if (!result.value) return NextResponse.json({ error: "project_not_found_or_not_owned" }, { status: 404, headers: NO_STORE });
  return NextResponse.json({ file: result.value }, { headers: NO_STORE });
}
