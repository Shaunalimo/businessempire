require 'sinatra'
require 'stripe'

# This is your test secret API key.
Stripe.api_key = 'sk_test_51QgmOvKpiU7VqUoNQti6K6bMCmTvMV7gIhFuqbfB629RTUsgXA65R5EsTkLCfQ0SKe0FLNfhDi63FMFE6eRTr5if00DfwNxWfW'

Stripe.api_version = '2023-10-16'

set :static, true
set :port, 4242
set :public_folder, 'dist'

post '/account/:account' do
  content_type 'application/json'

  begin
    connected_account_id = params[:account]
    account = Stripe::Account.update(
      connected_account_id,
      {
        business_type: 'individual',
      }
    )

    {
      account: account[:id]
    }.to_json
  rescue => error
    puts "An error occurred when calling the Stripe API to update an account: #{error.message}";
    return [500, { error: error.message }.to_json]
  end
end

post '/account' do
  content_type 'application/json'

  begin
    account = Stripe::Account.create({
      controller: {
        stripe_dashboard: {
          type: "none",
        },
        fees: {
          payer: "application"
        },
        losses: {
          payments: "application"
        },
        requirement_collection: "application",
      },
      capabilities: {
        transfers: {requested: true}
      },
      country: "GB",
    })

    {
      account: account[:id]
    }.to_json
  rescue => error
    puts "An error occurred when calling the Stripe API to create an account: #{error.message}";
    return [500, { error: error.message }.to_json]
  end
end

get '/*path' do
  send_file File.join(settings.public_folder, 'index.html')
end